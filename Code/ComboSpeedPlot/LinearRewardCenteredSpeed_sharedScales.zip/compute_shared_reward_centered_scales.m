function shared = compute_shared_reward_centered_scales(Pall, cfg)
% COMPUTE_SHARED_REWARD_CENTERED_SCALES
% Calculates common display scales for all selected sessions.
%
% Returned fields:
%   heatmapCLim       [minimum maximum] speed color limits
%   speedYLim         [minimum maximum] average-speed y-axis
%   accelerationYLim  symmetric signed-acceleration y-axis

nFiles = numel(Pall);

if nFiles < 1
    error('Pall is empty.');
end

%% Shared heatmap color scale
localColorMax = nan(nFiles, 1);

for f = 1:nFiles
    vals = Pall{f}.speedMat(isfinite(Pall{f}.speedMat));

    if isempty(vals)
        continue
    end

    if cfg.usePercentileColorMax
        localColorMax(f) = prctile(vals, cfg.colorMaxPercentile);
    else
        localColorMax(f) = max(vals);
    end
end

validColor = isfinite(localColorMax);

if ~any(validColor)
    error('No finite speed values were found for the heatmap scale.');
end

% Use the largest session-specific upper limit so no selected session is
% displayed with a narrower scale than it would receive independently.
heatmapMax = max(localColorMax(validColor));
heatmapMax = max(heatmapMax, eps);

shared.heatmapCLim = [0 heatmapMax];

%% Shared average-speed y-axis
allSpeedLower = [];
allSpeedUpper = [];

for f = 1:nFiles
    P = Pall{f};

    switch lower(cfg.outerSpeedStatistic)
        case 'mean'
            centerSpeed = mean(P.speedMat, 1, 'omitnan');

        case 'median'
            centerSpeed = median(P.speedMat, 1, 'omitnan');

        otherwise
            error('cfg.outerSpeedStatistic must be ''mean'' or ''median''.');
    end

    nPerBin = sum(isfinite(P.speedMat), 1);
    semSpeed = std(P.speedMat, 0, 1, 'omitnan') ./ sqrt(nPerBin);
    semSpeed(nPerBin == 0) = NaN;

    if cfg.smoothMeanSpeedBins > 1
        centerSpeed = movmean( ...
            centerSpeed, ...
            cfg.smoothMeanSpeedBins, ...
            'omitnan');

        semSpeed = movmean( ...
            semSpeed, ...
            cfg.smoothMeanSpeedBins, ...
            'omitnan');
    end

    lowerSpeed = centerSpeed - semSpeed;
    upperSpeed = centerSpeed + semSpeed;

    allSpeedLower = [ ...
        allSpeedLower, ...
        lowerSpeed(isfinite(lowerSpeed))]; %#ok<AGROW>

    allSpeedUpper = [ ...
        allSpeedUpper, ...
        upperSpeed(isfinite(upperSpeed))]; %#ok<AGROW>
end

if isempty(allSpeedLower) || isempty(allSpeedUpper)
    error('No finite average-speed values were found.');
end

speedMin = min(allSpeedLower);
speedMax = max(allSpeedUpper);
speedRange = speedMax - speedMin;

speedPad = max(2, 0.10 * max(speedRange, 1));

speedYMin = max(0, floor(speedMin - speedPad));
speedYMax = ceil(speedMax + speedPad);

if speedYMax <= speedYMin
    speedYMax = speedYMin + 5;
end

shared.speedYLim = [speedYMin speedYMax];

%% Shared symmetric acceleration y-axis
allAccelMagnitude = [];

for f = 1:nFiles
    P = Pall{f};

    if ~isfield(P, 'accelMat')
        error('Pall{%d}.accelMat is missing.', f);
    end

    meanAccel = mean(P.accelMat, 1, 'omitnan');

    nPerBin = sum(isfinite(P.accelMat), 1);
    semAccel = std(P.accelMat, 0, 1, 'omitnan') ./ sqrt(nPerBin);
    semAccel(nPerBin == 0) = NaN;

    if cfg.smoothAccelerationBins > 1
        meanAccel = movmean( ...
            meanAccel, ...
            cfg.smoothAccelerationBins, ...
            'omitnan');

        semAccel = movmean( ...
            semAccel, ...
            cfg.smoothAccelerationBins, ...
            'omitnan');
    end

    lowerAccel = meanAccel - semAccel;
    upperAccel = meanAccel + semAccel;

    finiteAccel = [ ...
        lowerAccel(isfinite(lowerAccel)), ...
        upperAccel(isfinite(upperAccel))];

    allAccelMagnitude = [ ...
        allAccelMagnitude, ...
        abs(finiteAccel)]; %#ok<AGROW>
end

if isempty(allAccelMagnitude)
    accelLimit = 1;
else
    accelLimit = 1.10 * max(allAccelMagnitude);
end

if accelLimit <= 10
    accelLimit = ceil(accelLimit);
elseif accelLimit <= 50
    accelLimit = ceil(accelLimit / 5) * 5;
else
    accelLimit = ceil(accelLimit / 10) * 10;
end

accelLimit = max(accelLimit, 1);

shared.accelerationYLim = [-accelLimit accelLimit];

end
