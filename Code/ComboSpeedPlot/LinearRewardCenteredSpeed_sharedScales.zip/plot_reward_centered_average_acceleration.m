function S = plot_reward_centered_average_acceleration(P, cfg, ax)
% PLOT_REWARD_CENTERED_AVERAGE_ACCELERATION
% Plots mean signed acceleration across laps with SEM.

axes(ax);
cla(ax);
hold(ax, 'on');

if ~isfield(P, 'accelMat')
    error('P.accelMat is missing.');
end

%% Across-lap mean and SEM
meanAccel = mean(P.accelMat, 1, 'omitnan');

nPerBin = sum(isfinite(P.accelMat), 1);
semAccel = std(P.accelMat, 0, 1, 'omitnan') ./ sqrt(nPerBin);
semAccel(nPerBin == 0) = NaN;

if cfg.smoothAccelerationBins > 1
    meanAccel = movmean( ...
        meanAccel, ...
        cfg.smoothAccelerationBins, ...
        'omitnan');

    semAccel = movmean( ...
        semAccel, ...
        cfg.smoothAccelerationBins, ...
        'omitnan');
end

validMean = isfinite(meanAccel);

if ~any(validMean)
    error('No valid acceleration values are available for plotting.');
end

%% Close the unfolded curve
edgeMean = mean( ...
    [meanAccel(1), meanAccel(end)], ...
    'omitnan');

edgeSEM = mean( ...
    [semAccel(1), semAccel(end)], ...
    'omitnan');

xPlot = [-180, P.relativeCenters_deg, 180];
meanPlot = [edgeMean, meanAccel, edgeMean];
semPlot = [edgeSEM, semAccel, edgeSEM];

lowerPlot = meanPlot - semPlot;
upperPlot = meanPlot + semPlot;

goodBand = isfinite(xPlot) & ...
           isfinite(lowerPlot) & ...
           isfinite(upperPlot);

%% SEM band
fill(ax, ...
    [xPlot(goodBand), fliplr(xPlot(goodBand))], ...
    [lowerPlot(goodBand), fliplr(upperPlot(goodBand))], ...
    [0.40 0.40 0.40], ...
    'FaceAlpha', 0.30, ...
    'EdgeColor', 'none');

%% Mean acceleration
plot(ax, ...
    xPlot, ...
    meanPlot, ...
    'k-', ...
    'LineWidth', cfg.outerLineWidth);

%% Zero and reward references
yline(ax, 0, '--', ...
    'Color', [0.35 0.35 0.35], ...
    'LineWidth', 1.0);

xline(ax, 0, '-', ...
    'Color', cfg.rewardGuideColor, ...
    'LineWidth', cfg.rewardGuideLineWidth);

%% Select acceleration y-axis
if isfield(cfg, 'sharedAccelerationYLim')
    accelerationYLim = cfg.sharedAccelerationYLim;
else
    finiteBand = [ ...
        lowerPlot(isfinite(lowerPlot)), ...
        upperPlot(isfinite(upperPlot))];

    maxAbs = max(abs(finiteBand));

    if isempty(maxAbs) || ~isfinite(maxAbs) || maxAbs == 0
        maxAbs = 1;
    end

    maxAbs = 1.10 * maxAbs;

    if maxAbs <= 10
        yLimit = ceil(maxAbs);
    elseif maxAbs <= 50
        yLimit = ceil(maxAbs / 5) * 5;
    else
        yLimit = ceil(maxAbs / 10) * 10;
    end

    yLimit = max(yLimit, 1);
    accelerationYLim = [-yLimit yLimit];
end

%% Actual track-degree labels
relativeTicks = [-180 -90 0 90 180];
actualTicks = mod(P.reward_deg + relativeTicks, 360);

tickLabels = arrayfun( ...
    @(x) sprintf('%.0f%c', x, char(176)), ...
    actualTicks, ...
    'UniformOutput', false);

set(ax, ...
    'XLim', [-180 180], ...
    'YLim', accelerationYLim, ...
    'XTick', relativeTicks, ...
    'XTickLabel', tickLabels, ...
    'FontSize', cfg.axisFontSize, ...
    'Layer', 'top');

xlabel(ax, 'Track position');
ylabel(ax, 'Acceleration (cm/s^2)');

title(ax, sprintf( ...
    'Mean signed acceleration +/- SEM  |  window %.2f s', ...
    cfg.accelerationWindow_s), ...
    'FontWeight', 'normal', ...
    'FontSize', max(cfg.axisFontSize - 1, 8));

grid(ax, 'on');
box(ax, 'on');

S.meanAcceleration = meanAccel;
S.semAcceleration = semAccel;
S.rewardDeg = P.reward_deg;
S.nTrials = P.nTrials;

end
