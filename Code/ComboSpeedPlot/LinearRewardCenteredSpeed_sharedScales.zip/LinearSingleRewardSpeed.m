clear; clc;

% Linear, reward-centered single-reward kinematics.
%
% For each selected session:
%   top:    lap-by-position speed heatmap
%   middle: average speed +/- SEM
%   bottom: average signed acceleration +/- SEM
%
% When multiple sessions are selected:
%   - all heatmaps use the same speed color scale
%   - all average-speed plots use the same y-axis scale
%   - all acceleration plots use the same symmetric y-axis scale
%
% Positive acceleration means speeding up.
% Negative acceleration means slowing down.

cfg = get_single_reward_config();

%% Acceleration settings
if ~isfield(cfg, 'accelerationWindow_s')
    cfg.accelerationWindow_s = 0.30;
end

if ~isfield(cfg, 'accelerationMinPoints')
    cfg.accelerationMinPoints = 5;
end

if ~isfield(cfg, 'smoothAccelerationBins')
    cfg.smoothAccelerationBins = cfg.smoothMeanSpeedBins;
end

% Set false to restore independent scaling for each session.
if ~isfield(cfg, 'useSharedSessionScales')
    cfg.useSharedSessionScales = true;
end

[file, path] = uigetfile('*.txt', ...
    'Select VR session file(s)', ...
    'MultiSelect', 'on');

if isequal(file, 0)
    error('No file selected.');
end

if ischar(file)
    file = {file};
end

%% Sort selected files chronologically
fileDates = NaT(numel(file), 1);

for k = 1:numel(file)
    tok = regexp(file{k}, '(\d{4}-\d{2}-\d{2})', ...
        'tokens', 'once');

    if ~isempty(tok)
        fileDates(k) = datetime(tok{1}, ...
            'InputFormat', 'yyyy-MM-dd');
    end
end

[~, sortIdx] = sort(fileDates);
file = file(sortIdx);

nFiles = numel(file);

%% First pass: process every session before plotting
Pall = cell(nFiles, 1);
mouseNames = cell(nFiles, 1);
sessionDates = cell(nFiles, 1);
keepFile = false(nFiles, 1);

for f = 1:nFiles

    fname = fullfile(path, file{f});

    [mouseName, sessionDate] = parse_mouse_date(file{f});
    mouseNames{f} = mouseName;
    sessionDates{f} = sessionDate;

    D = read_vr_session_txt(fname);

    D.pos_cm_wrapped = mod( ...
        (D.pos_deg / 360) * cfg.track_cm, ...
        cfg.track_cm);

    D.pos_cm_unwrapped = ...
        rad2deg(unwrap(deg2rad(D.pos_deg))) / 360 * cfg.track_cm;

    %% Window-based speed
    D.speed_cm_s = compute_window_speed( ...
        D.t, ...
        D.pos_cm_unwrapped, ...
        cfg.speedWindow_cm_forPlot);

    if cfg.useSpeedThreshold
        D.speed_cm_s(D.speed_cm_s < cfg.minSpeed_cm_s) = NaN;
    end

    %% Window-based signed acceleration
    D.accel_cm_s2 = compute_window_acceleration( ...
        D.t, ...
        D.speed_cm_s, ...
        cfg.accelerationWindow_s, ...
        cfg.accelerationMinPoints);

    lapStartIdx = detect_laps_from_wrap(D.pos_deg);
    nTrialsTotal = numel(lapStartIdx) - 1;

    if nTrialsTotal < 1
        warning('No complete laps in %s. File skipped.', file{f});
        continue
    end

    trialNums = 1:nTrialsTotal;

    P = build_reward_centered_speed_matrix( ...
        D, ...
        lapStartIdx, ...
        trialNums, ...
        cfg);

    P.nTrialsTotal = nTrialsTotal;
    P.fileName = file{f};

    Pall{f} = P;
    keepFile(f) = true;

    fprintf([ ...
        '%s %s: %d complete laps, reward center %.1f deg, ' ...
        'acceleration window %.2f s\n'], ...
        mouseName, ...
        sessionDate, ...
        nTrialsTotal, ...
        P.reward_deg, ...
        cfg.accelerationWindow_s);
end

%% Remove skipped files
Pall = Pall(keepFile);
mouseNames = mouseNames(keepFile);
sessionDates = sessionDates(keepFile);
file = file(keepFile);

nFiles = numel(Pall);

if nFiles == 0
    error('None of the selected files contained a complete lap.');
end

%% Calculate common scales across all selected sessions
if cfg.useSharedSessionScales && nFiles > 1
    shared = compute_shared_reward_centered_scales(Pall, cfg);

    cfg.sharedHeatmapCLim = shared.heatmapCLim;
    cfg.sharedSpeedYLim = shared.speedYLim;
    cfg.sharedAccelerationYLim = shared.accelerationYLim;

    fprintf('Shared heatmap scale: %.1f to %.1f cm/s\n', ...
        cfg.sharedHeatmapCLim(1), cfg.sharedHeatmapCLim(2));

    fprintf('Shared average-speed scale: %.1f to %.1f cm/s\n', ...
        cfg.sharedSpeedYLim(1), cfg.sharedSpeedYLim(2));

    fprintf('Shared acceleration scale: %.1f to %.1f cm/s^2\n', ...
        cfg.sharedAccelerationYLim(1), ...
        cfg.sharedAccelerationYLim(2));
end

%% Create figure after all scales are known
figWidth = min(0.98, max(0.58, 0.29 * nFiles));

figure( ...
    'Color', 'w', ...
    'Units', 'normalized', ...
    'Position', [(1-figWidth)/2, 0.04, figWidth, 0.91]);

% Heatmap occupies the upper two rows.
tl = tiledlayout(4, nFiles, ...
    'TileSpacing', 'compact', ...
    'Padding', 'compact');

%% Second pass: plot every session using common scales
for f = 1:nFiles

    P = Pall{f};

    axHeat = nexttile(tl, f, [2 1]);
    plot_reward_centered_trial_speed( ...
        P, ...
        cfg, ...
        mouseNames{f}, ...
        sessionDates{f}, ...
        axHeat);

    axSpeed = nexttile(tl, 2*nFiles + f);
    plot_reward_centered_average_speed(P, cfg, axSpeed);

    axAccel = nexttile(tl, 3*nFiles + f);
    plot_reward_centered_average_acceleration(P, cfg, axAccel);

    linkaxes([axHeat, axSpeed, axAccel], 'x');
end
