function S = plot_reward_centered_average_speed(P, cfg, ax)
% PLOT_REWARD_CENTERED_AVERAGE_SPEED
% Plots the within-session average or median speed beneath the trial
% heatmap, centered on the actual reward position.

axes(ax);
cla(ax);
hold(ax, 'on');

%% Across-lap center and SEM
switch lower(cfg.outerSpeedStatistic)
    case 'mean'
        centerSpeed = mean(P.speedMat, 1, 'omitnan');
        centerLabel = 'Mean';

    case 'median'
        centerSpeed = median(P.speedMat, 1, 'omitnan');
        centerLabel = 'Median';

    otherwise
        error('cfg.outerSpeedStatistic must be ''mean'' or ''median''.');
end

nPerBin = sum(isfinite(P.speedMat), 1);
semSpeed = std(P.speedMat, 0, 1, 'omitnan') ./ sqrt(nPerBin);
semSpeed(nPerBin == 0) = NaN;

if cfg.smoothMeanSpeedBins > 1
    centerSpeed = movmean( ...
        centerSpeed, ...
        cfg.smoothMeanSpeedBins, ...
        'omitnan');

    semSpeed = movmean( ...
        semSpeed, ...
        cfg.smoothMeanSpeedBins, ...
        'omitnan');
end

validCenter = isfinite(centerSpeed);

if ~any(validCenter)
    error('No valid across-lap speed curve.');
end

%% Close the circular trace cleanly at the two unfolded ends
edgeCenter = mean( ...
    [centerSpeed(1), centerSpeed(end)], ...
    'omitnan');

edgeSEM = mean( ...
    [semSpeed(1), semSpeed(end)], ...
    'omitnan');

xPlot = [-180, P.relativeCenters_deg, 180];
centerPlot = [edgeCenter, centerSpeed, edgeCenter];
semPlot = [edgeSEM, semSpeed, edgeSEM];

lowerPlot = centerPlot - semPlot;
upperPlot = centerPlot + semPlot;

goodBand = isfinite(xPlot) & ...
           isfinite(lowerPlot) & ...
           isfinite(upperPlot);

%% Purple area corresponding to the circular radial fill
baseSpeed = cfg.outerSpeedMin_cm_s;

goodFill = isfinite(centerPlot);

fill(ax, ...
    [xPlot(goodFill), fliplr(xPlot(goodFill))], ...
    [baseSpeed * ones(1, sum(goodFill)), ...
     fliplr(centerPlot(goodFill))], ...
    [0.75 0.60 0.90], ...
    'FaceAlpha', 0.25, ...
    'EdgeColor', 'none');

%% SEM band
fill(ax, ...
    [xPlot(goodBand), fliplr(xPlot(goodBand))], ...
    [lowerPlot(goodBand), fliplr(upperPlot(goodBand))], ...
    [0.40 0.40 0.40], ...
    'FaceAlpha', 0.35, ...
    'EdgeColor', 'none');

%% Average-speed curve
plot(ax, ...
    xPlot, ...
    centerPlot, ...
    'k-', ...
    'LineWidth', cfg.outerLineWidth);

%% Summary values and reference lines
validValues = centerSpeed(validCenter);

minCenterSpeed = min(validValues);
avgCenterSpeed = mean(validValues);
maxCenterSpeed = max(validValues);

summarySpeeds = [ ...
    minCenterSpeed, ...
    avgCenterSpeed, ...
    maxCenterSpeed];

if cfg.showMeanSpeedSummaryCircles
    for k = 1:numel(summarySpeeds)
        yline(ax, summarySpeeds(k), ...
            'Color', cfg.summaryCircleColor, ...
            'LineStyle', cfg.summaryCircleLineStyle, ...
            'LineWidth', cfg.summaryCircleLineWidth);
    end
end

%% Reward center
xline(ax, 0, '-', ...
    'Color', cfg.rewardGuideColor, ...
    'LineWidth', cfg.rewardGuideLineWidth);

%% Actual track-degree tick labels
relativeTicks = [-180 -90 0 90 180];
actualTicks = mod(P.reward_deg + relativeTicks, 360);

tickLabels = arrayfun( ...
    @(x) sprintf('%.0f%c', x, char(176)), ...
    actualTicks, ...
    'UniformOutput', false);

set(ax, ...
    'XLim', [-180 180], ...
    'XTick', relativeTicks, ...
    'XTickLabel', tickLabels, ...
    'FontSize', cfg.axisFontSize, ...
    'Layer', 'top');

% Use the established circular speed range, while expanding it if required
% so the curve and SEM are not clipped.
finiteBand = [lowerPlot(isfinite(lowerPlot)), ...
              upperPlot(isfinite(upperPlot))];

if isempty(finiteBand)
    yMin = cfg.outerSpeedMin_cm_s;
    yMax = cfg.outerSpeedMax_cm_s;
else
    yMin = min(cfg.outerSpeedMin_cm_s, floor(min(finiteBand) / 10) * 10);
    yMax = max(cfg.outerSpeedMax_cm_s, ceil(max(finiteBand) / 10) * 10);
end

yMin = max(0, yMin);

if yMax <= yMin
    yMax = yMin + 10;
end

ylim(ax, [yMin yMax]);

xlabel(ax, 'Track position');
ylabel(ax, 'Speed (cm/s)');

title(ax, sprintf( ...
    'All %d laps   Min %.1f | %s %.1f | Max %.1f cm/s', ...
    P.nTrials, ...
    minCenterSpeed, ...
    centerLabel, ...
    avgCenterSpeed, ...
    maxCenterSpeed), ...
    'FontWeight', 'normal', ...
    'FontSize', max(cfg.axisFontSize - 1, 8));

grid(ax, 'on');
box(ax, 'on');

%% Optional output
S.minSpeed = minCenterSpeed;
S.centerSpeed = avgCenterSpeed;
S.maxSpeed = maxCenterSpeed;
S.rewardDeg = P.reward_deg;
S.nTrials = P.nTrials;

end
