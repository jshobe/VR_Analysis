clear; clc;

% Linear, reward-centered version of the single-reward circular speed plot.
% Select one or more session text files. Each selected session is displayed
% as:
%   top:    lap-by-position speed heatmap
%   bottom: average speed +/- SEM
%
% Required existing helper files:
%   get_single_reward_config.m
%   read_vr_session_txt.m
%   parse_mouse_date.m
%   detect_laps_from_wrap.m
%   compute_window_speed.m
%
% New helper files:
%   build_reward_centered_speed_matrix.m
%   plot_reward_centered_trial_speed.m
%   plot_reward_centered_average_speed.m

cfg = get_single_reward_config();

[file, path] = uigetfile('*.txt', ...
    'Select VR session file(s)', ...
    'MultiSelect', 'on');

if isequal(file, 0)
    error('No file selected.');
end

if ischar(file)
    file = {file};
end

%% Sort selected files chronologically using the date in the filename
fileDates = NaT(numel(file), 1);

for k = 1:numel(file)
    tok = regexp(file{k}, '(\d{4}-\d{2}-\d{2})', ...
        'tokens', 'once');

    if ~isempty(tok)
        fileDates(k) = datetime(tok{1}, ...
            'InputFormat', 'yyyy-MM-dd');
    end
end

[~, sortIdx] = sort(fileDates);
file = file(sortIdx);

nFiles = numel(file);

%% Create figure
figWidth = min(0.96, max(0.55, 0.28 * nFiles));

figure( ...
    'Color', 'w', ...
    'Units', 'normalized', ...
    'Position', [(1-figWidth)/2, 0.08, figWidth, 0.84]);

tl = tiledlayout(2, nFiles, ...
    'TileSpacing', 'compact', ...
    'Padding', 'compact');

%% Process and plot each session
for f = 1:nFiles

    fname = fullfile(path, file{f});

    [mouseName, sessionDate] = parse_mouse_date(file{f});

    D = read_vr_session_txt(fname);

    % Wrapped position is used for spatial binning.
    D.pos_cm_wrapped = mod((D.pos_deg / 360) * cfg.track_cm, ...
                           cfg.track_cm);

    % Unwrapped position is used for the window-based speed calculation.
    D.pos_cm_unwrapped = ...
        rad2deg(unwrap(deg2rad(D.pos_deg))) / 360 * cfg.track_cm;

    D.speed_cm_s = compute_window_speed( ...
        D.t, ...
        D.pos_cm_unwrapped, ...
        cfg.speedWindow_cm_forPlot);

    if cfg.useSpeedThreshold
        D.speed_cm_s(D.speed_cm_s < cfg.minSpeed_cm_s) = NaN;
    end

    lapStartIdx = detect_laps_from_wrap(D.pos_deg);

    nTrialsTotal = numel(lapStartIdx) - 1;

    if nTrialsTotal < 1
        warning('No complete laps in %s. File skipped.', file{f});
        continue
    end

    trialNums = 1:nTrialsTotal;

    P = build_reward_centered_speed_matrix( ...
        D, ...
        lapStartIdx, ...
        trialNums, ...
        cfg);

    P.nTrialsTotal = nTrialsTotal;
    P.fileName = file{f};

    fprintf('%s %s: %d complete laps, reward center %.1f deg\n', ...
        mouseName, sessionDate, nTrialsTotal, P.reward_deg);

    axHeat = nexttile(tl, f);
    plot_reward_centered_trial_speed( ...
        P, cfg, mouseName, sessionDate, axHeat);

    axMean = nexttile(tl, nFiles + f);
    plot_reward_centered_average_speed(P, cfg, axMean);
end
